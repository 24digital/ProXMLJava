package com.apress.javaxml.beans;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import java.util.Locale;
import java.util.ResourceBundle;

import com.apress.javaxml.service.UserLocal;

public class UserBean {

	@EJB
	private UserLocal usersvc;

	private String email;

	private String password;

	private String oldpwd;

	private String confirm;

	private UIInput passwordInput;

	public UserBean() {

	}

	public UIInput getPasswordInput() {
		return passwordInput;
	}

	public void setPasswordInput(UIInput passwordInput) {
		this.passwordInput = passwordInput;
	}

	
	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public void setConfirm(String confirm) {
		this.confirm = confirm;
	}

	public String getConfirm() {
		return confirm;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setOldpwd(String oldpwd) {
		this.oldpwd = oldpwd;
	}

	public String getOldpwd() {
		return oldpwd;
	}

	public String loginAction() {
		String outcome = "success";

		try {
			usersvc.login(email, password);
		} catch (Exception e) {
			outcome = "failure";
			FacesContext context = FacesContext.getCurrentInstance();
			FacesMessage message = this.getMessage(context, "loginFailed");
			message.setSeverity(FacesMessage.SEVERITY_ERROR);
			context.addMessage(FacesMessage.FACES_MESSAGES, message);
		}

		return outcome;
	}

	public String registerAction() {
		String outcome = "success";

		try {
			usersvc.register(email, password);
		} catch (Exception e) {
			outcome = "failure";
			FacesContext context = FacesContext.getCurrentInstance();
			FacesMessage message = this.getMessage(context, "registerFailed");
			message.setSeverity(FacesMessage.SEVERITY_ERROR);
			context.addMessage(FacesMessage.FACES_MESSAGES, message);
		}

		return outcome;
	}

	public String chgpwdAction() {
		String outcome = "success";

		try {
			usersvc.changePwd(email, oldpwd, password);
			FacesContext context = FacesContext.getCurrentInstance();
			FacesMessage message = this.getMessage(context, "chgpwdSuccess");
			message.setSeverity(FacesMessage.SEVERITY_INFO);
			context.addMessage(FacesMessage.FACES_MESSAGES, message);
		} catch (Exception e) {
			outcome = "failure";
			FacesContext context = FacesContext.getCurrentInstance();
			FacesMessage message = this.getMessage(context, "chgpwdFailed");
			message.setSeverity(FacesMessage.SEVERITY_ERROR);
			context.addMessage(FacesMessage.FACES_MESSAGES, message);
		}

		return outcome;
	}

	private FacesMessage getMessage(FacesContext context, String key) {
		Locale locale = null;

		UIViewRoot root = context.getViewRoot();

		if (root != null)
			locale = root.getLocale();
		if (locale == null)
			locale = Locale.getDefault();

		ResourceBundle bundle = ResourceBundle.getBundle(
				"com.apress.javaxml.i18n.messages", locale);
		String msg = bundle.getString(key);
		return new FacesMessage(msg);
	}

	public void validateEmail(FacesContext context, UIComponent component,
			Object value) {
		
		if (value != null) {
			String email = (String) value;
			if (!email.contains("@")) {
				FacesMessage message = getMessage(context, "invalidEmail");
				message.setSeverity(FacesMessage.SEVERITY_ERROR);
				throw new ValidatorException(message);
			}
		}
	}

	public void confirmPassword(FacesContext context, UIComponent component,
			Object value) {
		
		if (passwordInput != null) {

			String pvalue = (String) passwordInput.getLocalValue();

			if (!pvalue.equals(value)) {
				FacesMessage message = getMessage(context, "confirmError");
				message.setSeverity(FacesMessage.SEVERITY_ERROR);
				throw new ValidatorException(message);
			}
		}
	}
}
