package com.apress.javaxml.ws.impl;

import java.io.ByteArrayOutputStream;
import java.util.Set;
import java.util.logging.Logger;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

/*
 * This simple SOAPHandler will log all messages
 */
public class LoggingHandler implements SOAPHandler<SOAPMessageContext> {

	private static Logger logger = Logger.getLogger(LoggingHandler.class
			.getName());

	// change this to redirect output if desired
	public Set<QName> getHeaders() {
		return null;
	}

	public boolean handleMessage(SOAPMessageContext smc) {
		log(smc.getMessage());
		return true;
	}

	public boolean handleFault(SOAPMessageContext smc) {
		return true;
	}

	// nothing to clean up
	public void close(MessageContext messageContext) {
	}

	private void log(SOAPMessage message) {
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			message.writeTo(out);
			logger.info(out.toString());
		} catch (Exception e) {
		}
	}
}
