package com.apress.javaxml.ws.impl;

import javax.activation.DataHandler;
import javax.ejb.EJB;
import javax.xml.ws.Holder;

import com.apress.javaxml.ws.AuthDetail;
import com.apress.javaxml.ws.FaultDetail;
import com.apress.javaxml.ws.ProjectInfo;
import com.apress.javaxml.ws.Projects;
import com.apress.javaxml.ws.ProjectsDetail;
import com.apress.javaxml.ws.UserInfo;
import com.apress.javaxml.ws.ProjectFault;
import com.apress.javaxml.service.ProjectLocal;
import com.apress.javaxml.service.UserLocal;

@javax.jws.WebService(targetNamespace = "http://www.apress.com/xmljava/webservices/definitions", serviceName = "ProjectPortTypeImplService", portName = "ProjectPortTypeImplPort", endpointInterface = "com.apress.javaxml.ws.ProjectPortType", wsdlLocation = "WEB-INF/wsdl/services.wsdl")
public class ProjectPortTypeImpl {
	@EJB
	private ProjectLocal projectLocal;

	@EJB
	private UserLocal userLocal;

	public void downloadProject(UserInfo user, ProjectInfo project,
			Holder<ProjectInfo> manifestHolder, Holder<DataHandler> dhHolder)
			throws ProjectFault {
		try {
			// download zip file
			manifestHolder.value = project;
			DataHandler dh = projectLocal.downloadZipFile(user,
					manifestHolder.value);

			// put data handler in data handler holder
			dhHolder.value = dh;
		} catch (Exception e) {
			FaultDetail detail = new FaultDetail();
			detail.setMajor("DOWNLOAD");
			detail.setMinor("NONE");
			throw new ProjectFault(e.getMessage(), detail);
		}
	}

	public ProjectInfo uploadProject(UserInfo user, ProjectInfo manifest,
			DataHandler zip) throws ProjectFault {

		try {
			// upload zip file
			projectLocal.uploadZipFile(user, manifest, zip);
		} catch (Exception e) {
			FaultDetail detail = new FaultDetail();
			detail.setMajor("UPLOAD");
			detail.setMinor("NONE");
			throw new ProjectFault(e.getMessage(), detail);
		}
		return manifest;
	}

	public void removeProject(UserInfo user, ProjectInfo remove) {
		projectLocal.remove(user, remove);
	}

	public Projects getProjects(UserInfo user, ProjectsDetail projectsDetail)
			throws ProjectFault {

		Projects projects = null;
		try {
			// get projects
			projects = projectLocal.getProjects(user, projectsDetail);
		} catch (Exception e) {
			FaultDetail detail = new FaultDetail();
			detail.setMajor("GETPROJECTS");
			detail.setMinor("NONE");
			throw new ProjectFault(e.getMessage(), detail);
		}
		return projects;
	}

	public void authenticate(Holder<UserInfo> userInfoHolder,
			Holder<AuthDetail> authDetailHolder) throws ProjectFault {
		try {
			UserInfo userInfo = userInfoHolder.value;
			userLocal.login(userInfo.getEmail(), userInfo.getPwd());
		} catch (Exception e) {
			FaultDetail detail = new FaultDetail();
			detail.setMajor("AUTHENTICATE");
			detail.setMinor("NONE");
			throw new ProjectFault(e.getMessage(), detail);
		}
	}

}
