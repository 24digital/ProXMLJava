package com.apress.javaxml.service;

import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import java.util.Collection;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.apress.javaxml.ws.*;
import com.apress.javaxml.persistence.*;

@Stateless
public class ProjectService implements ProjectLocal {
	@PersistenceContext
	private EntityManager em;

	/**
	 * gets cannonical location correponding to a location.
	 * 
	 * @param location
	 *            raw location
	 * @return canonical location
	 */
	private String getCanonicalLocation(String location) {

		if (location == null || location.trim().length() == 0) {
			location = ".";
		} else {
			location = location.trim();
		}

		location.replace(File.separatorChar, '/');
		if (!location.endsWith("/")) {
			location += "/";
		}

		return location;
	}

	/**
	 * authenticate user and return user entity
	 * 
	 * @param userInfo
	 *            given user info
	 * @return user entity
	 */
	private User authenticate(UserInfo userInfo) {
		// find user
		User user = em.find(User.class, userInfo.getEmail());

		// authenticate
		if (user == null
				|| !((user.getPwd() == null && userInfo.getPwd() == null) || (userInfo
						.getPwd().equals(user.getPwd())))) {
			Logger.getLogger(ProjectService.class.getName()).severe(
					"auth failed:" + userInfo.getEmail());
			throw new SecurityException("Authentication failed");
		}

		return user;
	}

	/**
	 * upload a folder into persistent storage
	 * 
	 * @param project
	 *            project in which to upload
	 * @param folderInfo
	 *            upload folder requested
	 * @param zipFile
	 *            zip file to upload from
	 * @throws IOException
	 */
	private void uploadFolder(Project project, FolderInfo folderInfo,
			ZipFile zipFile, Logger logger) throws IOException {

		folderInfo.setLocation(getCanonicalLocation(folderInfo.getLocation()));

		FolderKey fkey = new FolderKey(project.getOwnerId(), project.getName(),
				folderInfo.getLocation());
		logger.info("find folder:" + fkey);
		Folder folder = em.find(Folder.class, fkey);

		// create folder if it does not exist
		if (folder == null) {
			logger.info("create folder:" + fkey);
			folder = new Folder(project, folderInfo.getLocation());
			project.getFolders().add(folder);
			em.persist(folder);
			project.setLastUpdated(folder.getLastUpdated());
		}
		List<DocumentInfo> list = folderInfo.getDocument();
		Iterator<DocumentInfo> it = list.iterator();

		// iterate though requested folder documents
		while (it.hasNext()) {
			DocumentInfo docInfo = it.next();

			DocumentKey dkey = new DocumentKey(project.getOwnerId(), project
					.getName(), folder.getLocation(), docInfo.getName());
			logger.info("find doc:" + dkey);
			Document doc = em.find(Document.class, dkey);

			// if document does not exist in storage, create it
			if (doc == null) {
				logger.info("create doc:" + dkey);
				doc = new Document(folder, docInfo.getName());
				folder.getDocuments().add(doc);
				em.persist(doc);
				folder.setLastUpdated(doc.getLastUpdated());
			}

			// store the contents of the zip entry as document content
			try {
				ZipEntry zipEntry = new ZipEntry(folder.getLocation()
						+ doc.getName());
				if (zipEntry != null) {
					InputStream zipin = zipFile.getInputStream(zipEntry);

					if (zipin != null) {
						ByteArrayOutputStream baos = new ByteArrayOutputStream(
								1024);
						byte[] buf = new byte[1024];
						int nbytes = 0;
						while ((nbytes = zipin.read(buf, 0, buf.length)) > 0) {
							baos.write(buf, 0, nbytes);
						}
						logger.info("set contents:" + dkey + ":" + baos.size());
						doc.setContent(baos.toByteArray());
						java.sql.Timestamp ts = new java.sql.Timestamp(System
								.currentTimeMillis());
						doc.setLastUpdated(ts);
					}
				}
			} catch (IOException e) {
				logger.severe(dkey + ":" + e);
			}
		}
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public ProjectInfo uploadZipFile(UserInfo userInfo, ProjectInfo manifest,
			DataHandler dh) {
		ProjectInfo projectInfo = null;
		Logger logger = Logger.getLogger(ProjectService.class.getName());

		try {
			ZipFile zipFile = null;
			if (dh != null) {
				File temp = File.createTempFile("upload", ".zip");
				logger.info("writing zip file to:" + temp.getAbsolutePath());
				FileOutputStream fos = new FileOutputStream(temp);
				dh.writeTo(fos);
				fos.close();
				logger.info("opening zip file:" + temp.getAbsolutePath());
				zipFile = new ZipFile(temp);
			} else {
				throw new IllegalArgumentException("Null datahandler");
			}

			// auth user
			logger.info("auth:" + userInfo.getEmail());
			User user = authenticate(userInfo);

			// project is always uploaded to user email
			ProjectKey pkey = new ProjectKey(user.getEmail(), manifest
					.getName());

			logger.info("find project:" + pkey);
			Project project = em.find(Project.class, pkey);

			// if the project does not exist, create a new project
			if (project == null) {
				logger.info("create project:" + pkey);
				project = new Project(user, manifest.getName());
				user.getProjects().add(project);
				em.persist(project);
			}

			List<FolderInfo> list = manifest.getFolder();
			Iterator<FolderInfo> it = list.iterator();
			while (it.hasNext()) {
				FolderInfo folder = it.next();
				uploadFolder(project, folder, zipFile, logger);
			}

		} catch (Exception e) {
			logger.severe(userInfo.getEmail() + ":" + manifest.getName() + ":"
					+ e);
			throw new EJBException(e);
		}
		return projectInfo;
	}

	/**
	 * This is for the case where we are downloading requested documents in a
	 * folder
	 * 
	 * @param project
	 *            project
	 * @param folderInfo
	 *            download folder in request
	 * @param zipout
	 *            zip output
	 * @param fac
	 *            data type factory
	 * @throws IOException
	 */
	private void downloadFolder(Project project, FolderInfo folderInfo,
			ZipOutputStream zipout, DatatypeFactory fac) throws IOException {

		folderInfo.setLocation(folderInfo.getLocation());

		FolderKey fkey = new FolderKey(project.getOwnerId(), project.getName(),
				folderInfo.getLocation());
		Folder folder = em.find(Folder.class, fkey);

		// if requested folder does not exist, it is an error
		if (folder == null) {
			throw new IllegalArgumentException("Folder does not exist:" + fkey);
		}

		// update folder entry in manifest
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTimeInMillis(folder.getCreatedOn().getTime());
		XMLGregorianCalendar xgc = fac.newXMLGregorianCalendar(gc);
		folderInfo.setCreatedOn(xgc);

		gc.setTimeInMillis(folder.getLastUpdated().getTime());
		xgc = fac.newXMLGregorianCalendar(gc);
		folderInfo.setLastUpdated(xgc);

		List<DocumentInfo> list = folderInfo.getDocument();
		if (list.size() > 0) {
			// iterate through specific documents requested
			Iterator<DocumentInfo> it = list.iterator();

			while (it.hasNext()) {
				DocumentInfo docInfo = it.next();

				DocumentKey dkey = new DocumentKey(project.getOwnerId(),
						project.getName(), folder.getLocation(), docInfo
								.getName());
				Document doc = em.find(Document.class, dkey);

				// requested document does not exist, it is an error
				if (doc == null) {
					throw new IllegalArgumentException(
							"Document does not exist:" + dkey);
				}

				// load the contents of the zip entry
				ZipEntry zipEntry = new ZipEntry(folder.getLocation()
						+ doc.getName());
				zipout.putNextEntry(new ZipEntry(zipEntry));
				byte[] content = (byte[]) doc.getContent();

				zipout.write(content, 0, content.length);
				// Complete the entry
				zipout.closeEntry();

				// update manifest document entry
				gc.setTimeInMillis(doc.getCreatedOn().getTime());
				xgc = fac.newXMLGregorianCalendar(gc);
				docInfo.setCreatedOn(xgc);

				gc.setTimeInMillis(doc.getLastUpdated().getTime());
				xgc = fac.newXMLGregorianCalendar(gc);
				docInfo.setLastUpdated(xgc);
			}
		} else {
			Collection<Document> documents = folder.getDocuments();
			Iterator<Document> it = documents.iterator();

			while (it.hasNext()) {
				// itertate through all documents in folder because no
				// specific documents in the folder were requested
				Document doc = it.next();

				// load the contents of the zip entry
				ZipEntry zipEntry = new ZipEntry(folder.getLocation()
						+ doc.getName());
				zipout.putNextEntry(new ZipEntry(zipEntry));
				byte[] content = (byte[]) doc.getContent();

				zipout.write(content, 0, content.length);
				// Complete the entry
				zipout.closeEntry();

				// add new manifest doc type entry
				DocumentInfo docInfo = new DocumentInfo();
				docInfo.setName(doc.getName());

				gc.setTimeInMillis(doc.getCreatedOn().getTime());
				xgc = fac.newXMLGregorianCalendar(gc);
				docInfo.setCreatedOn(xgc);

				gc.setTimeInMillis(doc.getLastUpdated().getTime());
				xgc = fac.newXMLGregorianCalendar(gc);
				docInfo.setLastUpdated(xgc);

				folderInfo.getDocument().add(docInfo);
			}
		}
	}

	/**
	 * This is for the case where we have to download all the documents within a
	 * folder.
	 * 
	 * @param manifest
	 *            project manifest
	 * @param folder
	 *            given folders
	 * @param zipout
	 *            zip output
	 * @param fac
	 *            data type factory
	 * @throws IOException
	 */
	private void downloadFolder(ProjectInfo manifest, Folder folder,
			ZipOutputStream zipout, DatatypeFactory fac) throws IOException {

		String location = folder.getLocation();
		FolderInfo folderInfo = new FolderInfo();
		folderInfo.setLocation(location);

		GregorianCalendar gc = new GregorianCalendar();
		gc.setTimeInMillis(folder.getCreatedOn().getTime());
		XMLGregorianCalendar xgc = fac.newXMLGregorianCalendar(gc);
		folderInfo.setCreatedOn(xgc);

		gc.setTimeInMillis(folder.getLastUpdated().getTime());
		xgc = fac.newXMLGregorianCalendar(gc);
		folderInfo.setLastUpdated(xgc);

		manifest.getFolder().add(folderInfo);

		Collection<Document> documents = folder.getDocuments();
		Iterator<Document> it = documents.iterator();

		while (it.hasNext()) {
			Document doc = it.next();

			// load the contents of the zip entry
			ZipEntry zipEntry = new ZipEntry(location + doc.getName());
			zipout.putNextEntry(new ZipEntry(zipEntry));
			byte[] content = (byte[]) doc.getContent();

			zipout.write(content, 0, content.length);
			// Complete the entry
			zipout.closeEntry();

			// add manifest entry
			DocumentInfo docInfo = new DocumentInfo();
			docInfo.setName(doc.getName());

			gc.setTimeInMillis(doc.getCreatedOn().getTime());
			xgc = fac.newXMLGregorianCalendar(gc);
			docInfo.setCreatedOn(xgc);

			gc.setTimeInMillis(doc.getLastUpdated().getTime());
			xgc = fac.newXMLGregorianCalendar(gc);
			docInfo.setLastUpdated(xgc);

			folderInfo.getDocument().add(docInfo);
		}

	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public DataHandler downloadZipFile(UserInfo userInfo, ProjectInfo manifest) {

		Logger logger = Logger.getLogger(ProjectService.class.getName());
		DataHandler dh = null;
		try {
			File file = null;
			// auth user
			authenticate(userInfo);
			ProjectKey pkey = new ProjectKey(manifest.getEmail(), manifest
					.getName());

			// find project
			Project project = em.find(Project.class, pkey);

			// if the project does not exist, it is an error
			if (project == null) {
				throw new IllegalArgumentException("Project does not exist:"
						+ pkey);
			}

			DatatypeFactory fac = DatatypeFactory.newInstance();

			// create a temporary zip file
			file = File.createTempFile("download", ".zip");
			ZipOutputStream zipOut = new ZipOutputStream(new FileOutputStream(
					file));
			List<FolderInfo> list = manifest.getFolder();
			if (list.size() > 0) {
				// iterate through requested folders in manifest
				Iterator<FolderInfo> it = list.iterator();
				while (it.hasNext()) {
					FolderInfo folder = it.next();
					downloadFolder(project, folder, zipOut, fac);
				}
			} else {
				// download whole project because no specific folders are
				// requested in manifest
				Collection<Folder> folders = project.getFolders();
				Iterator<Folder> it = folders.iterator();
				while (it.hasNext()) {
					Folder folder = it.next();
					downloadFolder(manifest, folder, zipOut, fac);
				}
			}
			zipOut.close();

			// set time stamps in manifest
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTimeInMillis(project.getCreatedOn().getTime());
			XMLGregorianCalendar xgc = fac.newXMLGregorianCalendar(gc);
			manifest.setCreatedOn(xgc);

			gc.setTimeInMillis(project.getLastUpdated().getTime());
			xgc = fac.newXMLGregorianCalendar(gc);
			manifest.setLastUpdated(xgc);

			dh = new DataHandler(new FileDataSource(file));
		} catch (Exception e) {
			logger.severe(userInfo.getEmail() + ":" + manifest.getName() + ":"
					+ e);
			throw new EJBException(e);
		}
		return dh;
	}

	private void remove(Project project, FolderInfo folderInfo) {

		FolderKey fkey = new FolderKey(project.getOwnerId(), project.getName(),
				getCanonicalLocation(folderInfo.getLocation()));
		Folder folder = em.find(Folder.class, fkey);

		if (folder != null) {
			List<DocumentInfo> list = folderInfo.getDocument();

			if (list.size() > 0) {
				// iterate through specific documents requested
				Iterator<DocumentInfo> it = list.iterator();
				while (it.hasNext()) {
					DocumentInfo docInfo = it.next();
					DocumentKey dkey = new DocumentKey(project.getOwnerId(),
							project.getName(), getCanonicalLocation(folderInfo
									.getLocation()), docInfo.getName());
					Document doc = em.find(Document.class, dkey);

					if (doc != null) {
						folder.getDocuments().remove(doc);
						em.remove(doc);
					}
				}

			} else {
				// remove complete folder
				if (folder != null) {
					project.getFolders().remove(folder);
					em.remove(folder);
				}
			}
		}
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void remove(UserInfo userInfo, ProjectInfo manifest) {
		Logger logger = Logger.getLogger(ProjectService.class.getName());
		try {
			User user = this.authenticate(userInfo);
			ProjectKey pkey = new ProjectKey(userInfo.getEmail(), manifest
					.getName());

			Project project = em.find(Project.class, pkey);
			if (project != null) {
				List<FolderInfo> list = manifest.getFolder();
				if (list.size() > 0) {
					// iterate through requested folders in manifest
					Iterator<FolderInfo> it = list.iterator();
					while (it.hasNext()) {
						FolderInfo folder = it.next();
						remove(project, folder);
					}
				} else {
					// remove whole project because no specific folders are
					// requested in manifest
					user.getProjects().remove(project);
					em.remove(project);
				}
			}
		} catch (Exception e) {
			logger.severe(userInfo.getEmail() + ":" + manifest.getName() + ":"
					+ e);
			throw new EJBException(e);
		}
	}

	private DocumentInfo marshall(Document document, DatatypeFactory fac) {
		DocumentInfo documnetInfo = new DocumentInfo();

		GregorianCalendar gc = new GregorianCalendar();

		documnetInfo.setName(document.getName());

		gc.setTimeInMillis(document.getCreatedOn().getTime());
		XMLGregorianCalendar xgc = fac.newXMLGregorianCalendar(gc);
		documnetInfo.setCreatedOn(xgc);

		gc.setTimeInMillis(document.getLastUpdated().getTime());
		xgc = fac.newXMLGregorianCalendar(gc);
		documnetInfo.setLastUpdated(xgc);

		return documnetInfo;
	}

	private FolderInfo marshall(Folder folder, DatatypeFactory fac,
			ProjectsDetail detail) {
		FolderInfo folderInfo = new FolderInfo();
		folderInfo.setLocation(folder.getLocation());

		GregorianCalendar gc = new GregorianCalendar();
		gc.setTimeInMillis(folder.getCreatedOn().getTime());
		XMLGregorianCalendar xgc = fac.newXMLGregorianCalendar(gc);
		folderInfo.setCreatedOn(xgc);

		gc = new GregorianCalendar();
		gc.setTimeInMillis(folder.getLastUpdated().getTime());
		xgc = fac.newXMLGregorianCalendar(gc);
		folderInfo.setLastUpdated(xgc);

		if (detail.isDocuments()) {
			Collection<Document> docColl = folder.getDocuments();
			Iterator<Document> itd = docColl.iterator();

			while (itd.hasNext()) {
				Document document = itd.next();

				DocumentInfo documentInfo = marshall(document, fac);
				folderInfo.getDocument().add(documentInfo);
			}
		}

		return folderInfo;
	}

	private ProjectInfo marshall(Project project, DatatypeFactory fac,
			ProjectsDetail detail) {
		ProjectInfo projectInfo = new ProjectInfo();

		projectInfo.setEmail(project.getOwnerId());
		projectInfo.setName(project.getName());

		GregorianCalendar gc = new GregorianCalendar();
		gc.setTimeInMillis(project.getCreatedOn().getTime());
		XMLGregorianCalendar xgc = fac.newXMLGregorianCalendar(gc);
		projectInfo.setCreatedOn(xgc);

		gc.setTimeInMillis(project.getLastUpdated().getTime());
		xgc = fac.newXMLGregorianCalendar(gc);
		projectInfo.setLastUpdated(xgc);

		if (detail.isFolders()) {
			Collection<Folder> foldColl = project.getFolders();
			Iterator<Folder> itf = foldColl.iterator();

			while (itf.hasNext()) {
				Folder folder = itf.next();
				FolderInfo folderInfo = marshall(folder, fac, detail);

				projectInfo.getFolder().add(folderInfo);
			}
		}

		return projectInfo;
	}

	public Projects getProjects(UserInfo userInfo, ProjectsDetail detail) {
		Projects projects = new Projects();

		try {
			// find user
			User user = authenticate(userInfo);
			Collection<Project> projColl = user.getProjects();
			Iterator<Project> it = projColl.iterator();

			DatatypeFactory fac = DatatypeFactory.newInstance();
			while (it.hasNext()) {
				Project project = it.next();
				ProjectInfo projectInfo = marshall(project, fac, detail);
				projects.getProject().add(projectInfo);
			}
		} catch (Exception e) {
			throw new EJBException(e);
		}
		return projects;
	}

}
