package com.apress.javaxml.service;

import javax.ejb.Local;

@Local
public interface UserLocal {
	public void login(String email, String pwd);
	public void register(String email, String pwd);
	
	public void changePwd(String email, String cpwd, String npwd);
	
	public void unregister(String email, String pwd);
}
