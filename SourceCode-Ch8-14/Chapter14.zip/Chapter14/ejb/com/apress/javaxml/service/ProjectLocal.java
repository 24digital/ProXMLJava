package com.apress.javaxml.service;

import javax.activation.DataHandler;
import javax.ejb.Local;

import com.apress.javaxml.ws.*;

@Local
public interface ProjectLocal {
	public ProjectInfo uploadZipFile(UserInfo user, ProjectInfo manifest, DataHandler zip);

	public DataHandler downloadZipFile(UserInfo user, ProjectInfo manifest);
	
	public void remove(UserInfo user, ProjectInfo manifest);
	
	public Projects getProjects(UserInfo user, ProjectsDetail detail);
}
