package com.apress.javaxml.service;

import com.apress.javaxml.persistence.User;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class UserService implements UserLocal {
	@PersistenceContext
	private EntityManager em;

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void login(String email, String pwd) {
		User user = em.find(User.class, email);
		if (user == null) {
			throw new SecurityException("Invalid user:" + email);
		}

		if (pwd == null || !pwd.equals(user.getPwd())) {
			throw new SecurityException("Invalid password:" + email);
		}

	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void register(String email, String pwd) {
		User user = new User(email, pwd);
		em.persist(user);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void unregister(String email, String pwd) {
		User user = em.find(User.class, email);
		if (user != null) {
			if (user.getPwd() != null) {
				if (user.getPwd().equals(pwd)) {
					em.remove(user);
				} else {
					throw new SecurityException("Invalid password for:" + email);
				}
			} else {
				em.remove(user);
			}
		}
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void changePwd(String email, String cpwd, String npwd) {
		User user = em.find(User.class, email);
		if (user != null) {
			if (user.getPwd() != null) {
				if (user.getPwd().equals(cpwd)) {
					user.setPwd(npwd);
				} else {
					throw new SecurityException(
							"Current password is invalid for:" + email);
				}
			} else {
				user.setPwd(npwd);
			}
		} else {
			throw new IllegalArgumentException("User does not exist:" + email);
		}
	}
}
