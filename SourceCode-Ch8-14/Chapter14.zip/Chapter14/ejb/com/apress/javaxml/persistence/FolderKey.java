package com.apress.javaxml.persistence;

import java.io.Serializable;

public final class FolderKey implements Serializable {
	private String ownerId;

	private String projectName;

	private String location;

	public FolderKey() {
	}

	public FolderKey(String ownerId, String projectName, String location) {
		this.setOwnerId(ownerId);
		this.setProjectName(projectName);
		this.setLocation(location);
	}

	public int hashCode() {
		int ret = 0;

		if (ownerId != null)
			ret ^= ownerId.hashCode();

		if (projectName != null)
			ret ^= projectName.hashCode();

		if (location != null)
			ret ^= location.hashCode();

		return ret;
	}

	public boolean equals(Object otherOb) {
		if (this == otherOb) {
			return true;
		}

		if (!(otherOb instanceof FolderKey)) {
			return false;
		}

		FolderKey other = (FolderKey) otherOb;

		return (((this.getOwnerId() == null) ? (other.getOwnerId() == null)
				: this.getOwnerId().equals(other.getOwnerId()))
				&& (this.projectName == null ? other.getProjectName() == null
						: this.getProjectName() == other.getProjectName()) 
			    && (this.location == null ? other.getLocation() == null
				: this.location == other.getLocation()));
	}

	public String toString() {
		return "" + getOwnerId() + "-" + getProjectName()+"-"+getLocation();
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}
