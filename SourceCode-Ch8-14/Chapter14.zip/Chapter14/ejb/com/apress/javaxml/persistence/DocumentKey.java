package com.apress.javaxml.persistence;

import java.io.Serializable;

public class DocumentKey implements Serializable {
	private String ownerId;

	private String projectName;

	private String folderLocation;

	private String name;

	public DocumentKey() {
	}

	public DocumentKey(String ownerId, String projectName,
			String folderLocation, String name) {
		this.setOwnerId(ownerId);
		this.setProjectName(projectName);
		this.setFolderLocation(folderLocation);
		this.setName(name);
	}

	public int hashCode() {
		int ret = 0;

		if (ownerId != null)
			ret ^= ownerId.hashCode();

		if (projectName != null)
			ret ^= projectName.hashCode();

		if (folderLocation != null)
			ret ^= folderLocation.hashCode();

		if (name != null)
			ret ^= name.hashCode();

		return ret;
	}

	public boolean equals(Object otherOb) {
		if (this == otherOb) {
			return true;
		}

		if (!(otherOb instanceof DocumentKey)) {
			return false;
		}

		DocumentKey other = (DocumentKey) otherOb;

		return (((this.getOwnerId() == null) ? (other.getOwnerId() == null)
				: this.getOwnerId().equals(other.getOwnerId()))
				&& (this.projectName == null ? other.getProjectName() == null
						: this.getProjectName() == other.getProjectName())
				&& (this.folderLocation == null ? other.getFolderLocation() == null
						: this.folderLocation == other.getFolderLocation()) && (this.name == null ? other
				.getName() == null
				: this.name == other.getName()));
	}

	public String toString() {
		return "" + getOwnerId() + "-" + getProjectName() + "-"
				+ getFolderLocation() + "-" + getName();
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getFolderLocation() {
		return folderLocation;
	}

	public void setFolderLocation(String folderLocation) {
		this.folderLocation = folderLocation;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
