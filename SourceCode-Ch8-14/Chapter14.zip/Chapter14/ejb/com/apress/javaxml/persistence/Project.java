package com.apress.javaxml.persistence;

import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Collection;

@IdClass(ProjectKey.class)
@Entity
@Table(name="EJB_PROJECT")
public class Project {

	private String name;
	private Timestamp createdOn;
	private Timestamp lastUpdated;
	private User owner;
	private String ownerId;
	private Collection<Folder> folders;
	
	
	public Project() {
		
	}
	
	public Project(User owner, String name) {
		this.owner = owner;
		this.name = name;
		this.ownerId = owner.getEmail();
		Timestamp ts = new Timestamp(System.currentTimeMillis());
		this.createdOn = ts;
		this.lastUpdated = ts;
	}
	
	@Id
	@Column(name="NAME")
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	@Id
	@Column(name="OWNER_ID", nullable=false, insertable=false, updatable=false)
	public String getOwnerId() {
		return ownerId;
	}
	
	
	public void setOwnerId(String id) {
		this.ownerId = id;
	}
	
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	
	public void setCreatedOn(Timestamp ts) {
		this.createdOn = ts;
	}
	
	public Timestamp getLastUpdated() {
		return lastUpdated;
	}
	
	public void setLastUpdated(Timestamp ts) {
		this.lastUpdated = ts;
	}
	
	@ManyToOne
	@JoinColumn(name="OWNER_ID", referencedColumnName="EMAIL")
	public User getOwner() {
		return owner;
	}
	
	public void setOwner(User owner) {
		this.owner = owner;
	}
	
	@OneToMany(cascade=CascadeType.REMOVE, mappedBy="project")
	public Collection<Folder> getFolders() {
		return folders;
	}
	
	public void setFolders(Collection<Folder> folders) {
		this.folders = folders;
	}
}
