package com.apress.javaxml.persistence;

import java.util.*;

import javax.persistence.*;

import java.sql.Timestamp;

@IdClass(FolderKey.class)
@Entity
@Table(name = "EJB_FOLDER")
public class Folder {
	private String location;

	private Timestamp createdOn;

	private Timestamp lastUpdated;

	private Project project;

	private String ownerId;

	private String projectName;

	private String parentLocation;

	private Collection<Document> documents;

	public Folder() {

	}

	public Folder(Project project, String location) {
		this.project = project;
		this.location = location;
		this.projectName = project.getName();
		this.ownerId = project.getOwnerId();
		Timestamp ts = new Timestamp(System.currentTimeMillis());
		this.createdOn = ts;
		this.lastUpdated = ts;
	}

	@Id
	@Column(name = "LOCATION")
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Id
	@Column(name = "PROJECT_NAME", nullable = false, insertable = false, updatable = false)
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String name) {
		this.projectName = name;
	}

	@Id
	@Column(name = "OWNER_ID", nullable = false, insertable = false, updatable = false)
	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String id) {
		this.ownerId = id;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp ts) {
		this.createdOn = ts;
	}

	public Timestamp getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Timestamp ts) {
		this.lastUpdated = ts;
	}


	@ManyToOne
	@JoinColumns( {
			@JoinColumn(name = "PROJECT_NAME", referencedColumnName = "NAME"),
			@JoinColumn(name = "OWNER_ID", referencedColumnName = "OWNER_ID") })
	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "folder")
	public Collection<Document> getDocuments() {
		return documents;
	}

	public void setDocuments(Collection<Document> documents) {
		this.documents = documents;
	}

	
	public String getParentLocation() {
		return parentLocation;
	}

	public void setParentLocation(String loc) {
		this.parentLocation = loc;
	}

}