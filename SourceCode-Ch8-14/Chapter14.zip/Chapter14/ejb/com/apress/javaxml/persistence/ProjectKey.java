package com.apress.javaxml.persistence;

import java.io.Serializable;

public class ProjectKey implements Serializable {
	private String ownerId;

	private String name;

	public ProjectKey() {
	}

	public ProjectKey(String ownerId, String name) {
		this.setOwnerId(ownerId);
		this.setName(name);
	}

	public int hashCode() {
		int ret = 0;

		if (ownerId != null)
			ret ^= ownerId.hashCode();

		if (name != null)
			ret ^= name.hashCode();

		return ret;
	}

	public boolean equals(Object otherOb) {
		if (this == otherOb) {
			return true;
		}

		if (!(otherOb instanceof ProjectKey)) {
			return false;
		}

		ProjectKey other = (ProjectKey) otherOb;

		return (((this.getOwnerId() == null) ? (other.getOwnerId() == null)
				: this.getOwnerId().equals(other.getOwnerId())) && (this.name == null ? other
				.getName() == null
				: this.getName() == other.getName()));
	}

	public String toString() {
		return "" + getOwnerId() + "-" + getName();
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
