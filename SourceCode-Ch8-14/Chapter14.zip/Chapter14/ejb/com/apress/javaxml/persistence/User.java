package com.apress.javaxml.persistence;

import java.sql.Timestamp;
import java.util.*;
import javax.persistence.*;

@Entity
@Table(name="EJB_USER")
public class User {
	private String email;
	private String pwd;
	private Timestamp createdOn;
	private Timestamp lastUpdated;
	private Collection<Project> projects;
	
	public User() {
		
	}
	
	public User(String email, String pwd) {
		this.email = email;
		this.pwd = pwd;
	}
	
	@Id
	@Column(name="EMAIL")
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	
	public void setCreatedOn(Timestamp ts) {
		this.createdOn = ts;
	}
	
	public Timestamp getLastUpdated() {
		return lastUpdated;
	}
	
	public void setLastUpdated(Timestamp ts) {
		this.lastUpdated = ts;
	}
	
	public String getPwd() {
		return pwd;
	}
	
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	@OneToMany(cascade=CascadeType.REMOVE, mappedBy="owner")
	public Collection<Project> getProjects() {
		return projects;
	}
	
	public void setProjects(Collection<Project> projects) {
		this.projects = projects;
	}
}
