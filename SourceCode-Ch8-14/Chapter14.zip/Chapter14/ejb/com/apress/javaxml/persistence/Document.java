package com.apress.javaxml.persistence;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@IdClass(DocumentKey.class)
@Entity
@Table(name = "EJB_DOCUMENT")
@SecondaryTable(name = "EJB_DOCUMENT_CONTENT", pkJoinColumns = {
		@PrimaryKeyJoinColumn(name = "OWNER_ID", referencedColumnName = "OWNER_ID"),
		@PrimaryKeyJoinColumn(name = "PROJECT_NAME", referencedColumnName = "PROJECT_NAME"),
		@PrimaryKeyJoinColumn(name = "FOLDER_LOCATION", referencedColumnName = "FOLDER_LOCATION"),
		@PrimaryKeyJoinColumn(name = "NAME", referencedColumnName = "NAME") })
public class Document {
	private String folderLocation;

	private String name;

	private Serializable content;

	private Timestamp createdOn;

	private Timestamp lastUpdated;

	private Folder folder;

	private String ownerId;

	private String projectName;

	public Document() {

	}

	public Document(Folder folder, String name) {
		this.folder = folder;
		this.name = name;
		this.folderLocation = folder.getLocation();
		this.projectName = folder.getProjectName();
		this.ownerId = folder.getOwnerId();
		Timestamp ts = new Timestamp(System.currentTimeMillis());
		this.createdOn = ts;
		this.lastUpdated = ts;
		setContent(null);
	}

	@Id
	@Column(name = "NAME")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Id
	@Column(name = "FOLDER_LOCATION", nullable = false, insertable = false, updatable = false)
	public String getFolderLocation() {
		return folderLocation;
	}

	public void setFolderLocation(String loc) {
		this.folderLocation = loc;
	}

	@Id
	@Column(name = "PROJECT_NAME", nullable = false, insertable = false, updatable = false)
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String name) {
		this.projectName = name;
	}

	@Id
	@Column(name = "OWNER_ID", nullable = false, insertable = false, updatable = false)
	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String id) {
		this.ownerId = id;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp ts) {
		this.createdOn = ts;
	}

	public Timestamp getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Timestamp ts) {
		this.lastUpdated = ts;
	}

	@Lob
	@Column(table = "EJB_DOCUMENT_CONTENT", name = "CONTENT")
	public Serializable getContent() {
		return content;
	}

	public void setContent(Serializable content) {
		this.content = content;
	}

	@ManyToOne
	@JoinColumns( {
			@JoinColumn(name = "OWNER_ID", referencedColumnName = "OWNER_ID"),
			@JoinColumn(name = "PROJECT_NAME", referencedColumnName = "PROJECT_NAME"),
			@JoinColumn(name = "FOLDER_LOCATION", referencedColumnName = "LOCATION") })
	public Folder getFolder() {
		return folder;
	}

	public void setFolder(Folder folder) {
		this.folder = folder;
	}

}