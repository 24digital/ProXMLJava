package com.apress.javaxml.ws.client;

import javax.xml.namespace.QName;
import javax.xml.ws.Holder;

import java.io.File;
import java.io.FileOutputStream;
import java.net.*;
import java.util.*;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.activation.*;

import com.apress.javaxml.ws.*;

public class DownloadClient {
	private static ProjectPortTypeImplService service;

	private static final Logger logger = Logger.getLogger(ProjectClient.class
			.getName());

	private static String projectName;

	private static String email, pwd;

	private static URL wsdlUrl;

	private final static QName PROJECTSERVICE = new QName(
			"http://www.apress.com/xmljava/webservices/definitions",
			"ProjectPortTypeImplService");

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String[] args) {
		try {

			if (args.length == 4) {
				email = args[0];
				pwd = args[1];
				wsdlUrl = new URL(args[2]);
				projectName = args[3];
			} else {
				System.out
						.println("Usage: <email> <password> <wsdl URL> <project>");
				System.exit(1);
			}

			doProjectServiceTests();

		} catch (Exception e) {
			logger.severe(e.toString());
		}
	}

	private static void log(DocumentInfo dinfo) {
		logger.info("Document Name:" + dinfo.getName());
		logger.info("Document Created On:" + dinfo.getCreatedOn());
		logger.info("Document Last Updated On:" + dinfo.getLastUpdated());
	}

	private static void log(FolderInfo finfo) {
		logger.info("Folder Location:" + finfo.getLocation());
		logger.info("Folder Created On:" + finfo.getCreatedOn());
		logger.info("Folder Last Updated On:" + finfo.getLastUpdated());
		List<DocumentInfo> docs = finfo.getDocument();

		Iterator<DocumentInfo> it = docs.iterator();
		while (it.hasNext()) {
			DocumentInfo docInfo = it.next();
			log(docInfo);
		}
	}

	private static void log(ProjectInfo pinfo) {
		logger.info("Project Name:" + pinfo.getName());
		logger.info("Project Created On:" + pinfo.getCreatedOn());
		logger.info("Project Last Updated On:" + pinfo.getLastUpdated());
		List<FolderInfo> folders = pinfo.getFolder();

		Iterator<FolderInfo> it = folders.iterator();
		while (it.hasNext()) {
			FolderInfo folderInfo = it.next();
			log(folderInfo);
		}
	}

	private static void doProjectServiceTests() {
		try {
			logger.info("Create service for:" + wsdlUrl);
			service = new ProjectPortTypeImplService(wsdlUrl, PROJECTSERVICE);

			ProjectPortType port = service.getProjectPortTypeImplPort();

			UserInfo userInfo = new UserInfo();
			userInfo.setEmail(email);
			userInfo.setPwd(pwd);

			Holder<UserInfo> userInfoHolder = new Holder<UserInfo>();
			userInfoHolder.value = userInfo;
			logger.info("Authenticate user:" + userInfo.getEmail() + ":"
					+ userInfo.getPwd());

			AuthScope scope = new AuthScope();
			scope.setScope("session");

			AuthDetail authDetail = new AuthDetail();
			authDetail.setAny(scope);

			Holder<AuthDetail> authDetailHolder = new Holder<AuthDetail>();
			authDetailHolder.value = authDetail;

			try {
				port.authenticate(userInfoHolder, authDetailHolder);
			} catch (Exception e) {
				e.printStackTrace();
				logger.info("User is not authorized");
				System.exit(1);
			}
			logger.info("User is authorized");

			ProjectInfo projectInfo = new ProjectInfo();

			projectInfo.setName(projectName);
			projectInfo.setEmail(email);

			logger.info("Downloading Project:" + userInfo.getEmail() + ":"
					+ projectInfo.getName());
			Holder<ProjectInfo> mf = new Holder<ProjectInfo>();
			Holder<DataHandler> zip = new Holder<DataHandler>();

			port.downloadProject(userInfo, projectInfo, mf, zip);

			DataHandler dh = zip.value;

			if (dh != null) {
				File temp = File.createTempFile(projectInfo.getName(), ".zip");
				FileOutputStream fos = new FileOutputStream(temp);
				dh.writeTo(fos);
				fos.close();
				logger.info("Zip file downloaded to:" + temp.getAbsolutePath());
			}

		} catch (Exception ex) {
			logger.severe(ex.toString());
		}
	}

}
