package com.apress.javaxml.ws.client;

import javax.xml.namespace.QName;
import javax.xml.ws.Holder;

import java.io.File;
import java.io.FileOutputStream;
import java.net.*;
import java.util.*;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.activation.*;

import com.apress.javaxml.ws.*;

public class UploadClient {
	private static ProjectPortTypeImplService service;

	private static final Logger logger = Logger.getLogger(ProjectClient.class
			.getName());

	private static File zfile;

	private static String email, pwd;

	private static URL wsdlUrl;

	private final static QName PROJECTSERVICE = new QName(
			"http://www.apress.com/xmljava/webservices/definitions",
			"ProjectPortTypeImplService");

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String[] args) {
		try {

			if (args.length == 4) {
				email = args[0];
				pwd = args[1];
				wsdlUrl = new URL(args[2]);
				zfile = new File(args[3]);
			} else {
				System.out
						.println("Usage: <email> <password> <wsdl URL> <zipfile>");
				System.exit(1);
			}

			doProjectServiceTests();

		} catch (Exception e) {
			logger.severe(e.toString());
		}
	}

	private static void log(DocumentInfo dinfo) {
		logger.info("Document Name:" + dinfo.getName());
		logger.info("Document Created On:" + dinfo.getCreatedOn());
		logger.info("Document Last Updated On:" + dinfo.getLastUpdated());
	}

	private static void log(FolderInfo finfo) {
		logger.info("Folder Location:" + finfo.getLocation());
		logger.info("Folder Created On:" + finfo.getCreatedOn());
		logger.info("Folder Last Updated On:" + finfo.getLastUpdated());
		List<DocumentInfo> docs = finfo.getDocument();

		Iterator<DocumentInfo> it = docs.iterator();
		while (it.hasNext()) {
			DocumentInfo docInfo = it.next();
			log(docInfo);
		}
	}

	private static void log(ProjectInfo pinfo) {
		logger.info("Project Name:" + pinfo.getName());
		logger.info("Project Created On:" + pinfo.getCreatedOn());
		logger.info("Project Last Updated On:" + pinfo.getLastUpdated());
		List<FolderInfo> folders = pinfo.getFolder();

		Iterator<FolderInfo> it = folders.iterator();
		while (it.hasNext()) {
			FolderInfo folderInfo = it.next();
			log(folderInfo);
		}
	}

	private static void doProjectServiceTests() {
		try {

			logger.info("Create service for:" + wsdlUrl);
			service = new ProjectPortTypeImplService(wsdlUrl, PROJECTSERVICE);

			ProjectPortType port = service.getProjectPortTypeImplPort();

			UserInfo userInfo = new UserInfo();
			userInfo.setEmail(email);
			userInfo.setPwd(pwd);
			
			Holder<UserInfo> userInfoHolder = new Holder<UserInfo>();
			userInfoHolder.value = userInfo;
			logger.info("Authenticate user:" + userInfo.getEmail()+":"+userInfo.getPwd());
			
			AuthScope scope = new AuthScope();
			scope.setScope("session");
			
			AuthDetail authDetail = new AuthDetail();
			authDetail.setAny(scope);
			
			Holder<AuthDetail> authDetailHolder = new Holder<AuthDetail>();
			authDetailHolder.value = authDetail;
			
			try {
				port.authenticate(userInfoHolder, authDetailHolder);
			} catch(Exception e) {
				e.printStackTrace();
				logger.info("User is not authorized");
				System.exit(1);
			}
			logger.info("User is authorized");
			
			ProjectInfo projectInfo = new ProjectInfo();

			projectInfo.setName(zfile.getName());
			projectInfo.setEmail(email);
			
			ZipFile zipFile = new ZipFile(zfile);
			Enumeration entries = zipFile.entries();
			HashMap<String, FolderInfo> folderMap = new HashMap<String, FolderInfo>();

			while (entries.hasMoreElements()) {
				ZipEntry zipEntry = (ZipEntry) entries.nextElement();
				String entryName = zipEntry.getName();
				if (!zipEntry.isDirectory()) {
					String location = entryName.substring(0, entryName
							.lastIndexOf("/") + 1);
					String name = entryName.substring(entryName
							.lastIndexOf("/") + 1);
					FolderInfo folderInfo = (FolderInfo) folderMap
							.get(location);
					if (folderInfo == null) {
						folderInfo = new FolderInfo();
						folderMap.put(location, folderInfo);
						folderInfo.setLocation(location);
						projectInfo.getFolder().add(folderInfo);
					}
					DocumentInfo docInfo = new DocumentInfo();
					docInfo.setName(name);
					folderInfo.getDocument().add(docInfo);
				}
			}
			DataHandler dh = new DataHandler(new FileDataSource(zfile));

			logger.info("Uploading zip file:" + zfile.getName());
			ProjectInfo retProjectInfo = port.uploadProject(userInfo,
					projectInfo, dh);
			logger.info("Begin Upload Project Status");
			log(retProjectInfo);
			logger.info("End Upload Project Status");

			
		} catch (Exception ex) {
			logger.severe(ex.toString());
		}
	}

}
